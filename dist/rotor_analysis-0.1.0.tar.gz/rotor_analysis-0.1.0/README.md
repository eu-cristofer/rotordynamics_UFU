# Rotordynamics UFU
Repo to store rotordynamic codes and computation results developed in the context of my master studies

## Note to package it

Run the following commands to package it:

```
python setup.py sdist bdist_wheel
```

Them, you can install it with:

```
pip install -e .
```