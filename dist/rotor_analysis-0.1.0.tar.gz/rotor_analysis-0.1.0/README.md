# Rotordynamics UFU
Repo to store rotordynamic codes and computation results developed in the context of my master studies
